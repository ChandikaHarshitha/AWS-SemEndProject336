// Sample Lambda to get order status
exports.handler = async (event) => {
  return { statusCode: 200, body: 'Order status: delivered' };
};