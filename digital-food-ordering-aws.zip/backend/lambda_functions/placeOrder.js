// Sample Lambda to place order
exports.handler = async (event) => {
  return { statusCode: 200, body: 'Order placed!' };
};