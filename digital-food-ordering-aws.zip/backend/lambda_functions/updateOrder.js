// Sample Lambda to update order
exports.handler = async (event) => {
  return { statusCode: 200, body: 'Order updated!' };
};